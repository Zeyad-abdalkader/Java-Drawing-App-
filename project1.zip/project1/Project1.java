/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import javax.swing.JFrame;

/**
 *
 * @author zezok
 */
public class Project1 {

   
      public static void main(String[] args) {
        JFrame frame = new JFrame("Drawing Application");
        DrawingApp panel = new DrawingApp();
        frame.add(panel);
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    }
    

