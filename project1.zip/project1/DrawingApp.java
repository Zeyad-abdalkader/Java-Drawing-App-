/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class DrawingApp extends JPanel implements MouseListener, MouseMotionListener {

    private enum ShapeType { SQUARE, RECTANGLE, LINE, OVAL, FREEHAND, ERASER }
    private ShapeType currentShape = ShapeType.FREEHAND;

    private Point startPoint, endPoint;
    private List<Shape> shapes = new ArrayList<>();
    private List<Color> shapeColors = new ArrayList<>();
    private List<Stroke> shapeStrokes = new ArrayList<>();
    private List<Boolean> shapeFilled = new ArrayList<>(); // Track filled status
    private Color currentColor = Color.RED;
    private List<List<Point>> freehandLines = new ArrayList<>();
    private List<Color> freehandColors = new ArrayList<>();
    private List<Stroke> freehandStrokes = new ArrayList<>();

    private JRadioButton squareButton, rectangleButton, lineButton, ovalButton, freehandButton;
    private JRadioButton redButton, blueButton, blackButton;
    private JButton clearButton, eraserButton, undoButton, saveButton, openButton;
    private JCheckBox dashedCheckbox, filledCheckbox;
    private boolean isDashed = false;
    private boolean isFilled = false; // Track filled checkbox status
    private boolean eraserMode = false;

    private Stroke dashedStroke = new BasicStroke(
        3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{9}, 0
    );
    private Stroke solidStroke = new BasicStroke(3);

    private Stack<UndoableAction> actionStack = new Stack<>();
    private BufferedImage canvasImage;

    public DrawingApp() {
        setLayout(null);

        // Initialize the canvas image
        canvasImage = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);

        // Create buttons for shape selection
        lineButton = new JRadioButton("Line", true);
        squareButton = new JRadioButton("Square");
        rectangleButton = new JRadioButton("Rectangle");
        ovalButton = new JRadioButton("Oval");
        freehandButton = new JRadioButton("Freehand");

        // Create buttons for color selection
        redButton = new JRadioButton("Red", true);
        blueButton = new JRadioButton("Blue");
        blackButton = new JRadioButton("Black");

        ButtonGroup shapeGroup = new ButtonGroup();
        shapeGroup.add(lineButton);
        shapeGroup.add(squareButton);
        shapeGroup.add(rectangleButton);
        shapeGroup.add(ovalButton);
        shapeGroup.add(freehandButton);

        ButtonGroup colorGroup = new ButtonGroup();
        colorGroup.add(redButton);
        colorGroup.add(blueButton);
        colorGroup.add(blackButton);

        // Layout for buttons
        lineButton.setBounds(10, 40, 100, 20);
        squareButton.setBounds(10, 70, 100, 20);
        rectangleButton.setBounds(10, 100, 100, 20);
        ovalButton.setBounds(10, 130, 100, 20);
        freehandButton.setBounds(10, 160, 100, 20);
        redButton.setBounds(10, 190, 100, 20);
        blueButton.setBounds(10, 220, 100, 20);
        blackButton.setBounds(10, 250, 100, 20);

        this.add(lineButton);
        this.add(squareButton);
        this.add(rectangleButton);
        this.add(ovalButton);
        this.add(freehandButton);
        this.add(redButton);
        this.add(blueButton);
        this.add(blackButton);

        // Add action listeners
        lineButton.addActionListener(e -> currentShape = ShapeType.LINE);
        squareButton.addActionListener(e -> currentShape = ShapeType.SQUARE);
        rectangleButton.addActionListener(e -> currentShape = ShapeType.RECTANGLE);
        ovalButton.addActionListener(e -> currentShape = ShapeType.OVAL);
        freehandButton.addActionListener(e -> currentShape = ShapeType.FREEHAND);

        redButton.addActionListener(e -> currentColor = Color.RED);
        blueButton.addActionListener(e -> currentColor = Color.BLUE);
        blackButton.addActionListener(e -> currentColor = Color.BLACK);

        // Set up mouse listeners
        this.addMouseListener(this);
        this.addMouseMotionListener(this);

        // Clear button
        clearButton = new JButton("Clear All");
        clearButton.setBounds(10, 280, 100, 30);
        clearButton.addActionListener(e -> clearDrawing());
        this.add(clearButton);

        // Dashed line checkbox
        dashedCheckbox = new JCheckBox("Dashed Line", isDashed);
        dashedCheckbox.setBounds(10, 320, 120, 20);
        dashedCheckbox.addActionListener(e -> {
            isDashed = dashedCheckbox.isSelected();
            repaint();
        });
        this.add(dashedCheckbox);

        // Filled checkbox
        filledCheckbox = new JCheckBox("Filled", isFilled);
        filledCheckbox.setBounds(10, 350, 100, 20);
        filledCheckbox.addActionListener(e -> {
            isFilled = filledCheckbox.isSelected();
        });
        this.add(filledCheckbox);

        // Eraser button
        eraserButton = new JButton("Eraser");
        eraserButton.setBounds(10, 380, 100, 30);
        eraserButton.addActionListener(e -> {
            eraserMode = !eraserMode;
            if (eraserMode) {
                currentShape = ShapeType.ERASER;
                eraserButton.setText("Draw");
            } else {
                currentShape = ShapeType.FREEHAND;
                eraserButton.setText("Eraser");
            }
        });
        this.add(eraserButton);

        // Undo button
        undoButton = new JButton("Undo");
        undoButton.setBounds(10, 420, 100, 30);
        undoButton.addActionListener(e -> undoLastAction());
        this.add(undoButton);

        // Save button
        saveButton = new JButton("Save");
        saveButton.setBounds(10, 460, 100, 30);
        saveButton.addActionListener(e -> saveDrawing());
        this.add(saveButton);

        // Open button
        openButton = new JButton("Open");
        openButton.setBounds(10, 490, 100, 30);
        openButton.addActionListener(e -> openImage());
        this.add(openButton);
    }

    private void clearDrawing() {
        shapes.clear();
        shapeColors.clear();
        shapeStrokes.clear();
        shapeFilled.clear(); // Clear filled status list
        freehandLines.clear();
        freehandColors.clear();
        freehandStrokes.clear();
        actionStack.clear(); // Clear action stack
        Graphics2D g2d = canvasImage.createGraphics();
        g2d.setComposite(AlphaComposite.Clear);
        g2d.fillRect(0, 0, canvasImage.getWidth(), canvasImage.getHeight());
        g2d.setComposite(AlphaComposite.SrcOver);
        repaint();
    }

    private void addAction(UndoableAction action) {
        actionStack.push(action);
    }

    private void undoLastAction() {
        if (!actionStack.isEmpty()) {
            UndoableAction lastAction = actionStack.pop();
            lastAction.undo();
            repaint(); // Repaint after undoing
        } else {
            System.out.println("No actions to undo.");
        }
    }

    private void saveDrawing() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("PNG Images", "png"));
        int option = fileChooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                BufferedImage image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = image.createGraphics();
                paintComponent(g2d);
                g2d.dispose();
                ImageIO.write(image, "png", file);
                JOptionPane.showMessageDialog(this, "Drawing saved successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving drawing: " + e.getMessage());
            }
        }
    }

    private void openImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("PNG Images", "png"));
        int option = fileChooser.showOpenDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                BufferedImage image = ImageIO.read(file);
                Graphics2D g2d = canvasImage.createGraphics();
                g2d.drawImage(image, 0, 0, null);
                g2d.dispose();
                repaint();
                JOptionPane.showMessageDialog(this, "Image loaded successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error opening image: " + e.getMessage());
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.drawImage(canvasImage, 0, 0, null);

        // Draw shapes
        for (int i = 0; i < shapes.size(); i++) {
            g2d.setColor(shapeColors.get(i));
            g2d.setStroke(shapeStrokes.get(i));
            Shape shape = shapes.get(i);
            if (shapeFilled.get(i)) { // Check if the shape should be filled
                g2d.fill(shape);
            } else {
                g2d.draw(shape);
            }
        }

        // Draw freehand lines
        for (int i = 0; i < freehandLines.size(); i++) {
            g2d.setColor(freehandColors.get(i));
            g2d.setStroke(freehandStrokes.get(i));
            List<Point> line = freehandLines.get(i);
            for (int j = 0; j < line.size() - 1; j++) {
                Point p1 = line.get(j);
                Point p2 = line.get(j + 1);
                if (p1 != null && p2 != null) {
                    g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
                }
            }
        }

        // Draw current shape being created
        if (startPoint != null && endPoint != null) {
            Shape shape = createShape();
            if (shape != null) {
                g2d.setColor(currentColor);
                g2d.setStroke(isDashed ? dashedStroke : solidStroke);
                if (isFilled && (currentShape == ShapeType.RECTANGLE || currentShape == ShapeType.OVAL)) {
                    g2d.fill(shape); // Fill shape if checkbox is selected
                } else {
                    g2d.draw(shape);
                }
            }
        }
    }

    private Shape createShape() {
        int x = Math.min(startPoint.x, endPoint.x);
        int y = Math.min(startPoint.y, endPoint.y);
        int width = Math.abs(startPoint.x - endPoint.x);
        int height = Math.abs(startPoint.y - endPoint.y);

        switch (currentShape) {
            case LINE:
                return new Line2D.Float(startPoint.x, startPoint.y, endPoint.x, endPoint.y);
            case SQUARE:
                int size = Math.max(width, height);
                return new Rectangle2D.Float(x, y, size, size);
            case RECTANGLE:
                return new Rectangle2D.Float(x, y, width, height);
            case OVAL:
                return new Ellipse2D.Float(x, y, width, height);
            case ERASER:
                return new Rectangle2D.Float(startPoint.x, startPoint.y, 20, 20);
            default:
                return null;
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (currentShape == ShapeType.FREEHAND) {
            freehandLines.add(new ArrayList<>());
            freehandColors.add(currentColor);
            freehandStrokes.add(isDashed ? dashedStroke : solidStroke);
        } else {
            startPoint = e.getPoint();
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (currentShape == ShapeType.FREEHAND) {
            freehandLines.get(freehandLines.size() - 1).add(null); // End the current freehand line
            addAction(new FreehandAction(new ArrayList<>(freehandLines.get(freehandLines.size() - 1))));
        } else {
            endPoint = e.getPoint();
            Shape shape = createShape();
            if (shape != null) {
                shapes.add(shape);
                shapeColors.add(currentShape == ShapeType.ERASER ? getBackground() : currentColor);
                shapeStrokes.add(isDashed ? dashedStroke : solidStroke);
                shapeFilled.add(isFilled); // Add filled status to the list
                addAction(new ShapeAction(shape, currentShape == ShapeType.ERASER ? getBackground() : currentColor));
            }
            startPoint = null;
            endPoint = null;
            repaint();
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (currentShape == ShapeType.FREEHAND) {
            freehandLines.get(freehandLines.size() - 1).add(e.getPoint());
            repaint();
        } else {
            endPoint = e.getPoint();
            if (currentShape == ShapeType.ERASER) {
                Shape shape = createShape();
                if (shape != null) {
                    shapes.add(shape);
                    shapeColors.add(getBackground());
                    shapeStrokes.add(solidStroke);
                    shapeFilled.add(false); // Eraser shapes are not filled
                    addAction(new EraserAction(shape));
                }
                startPoint = endPoint;
            }
            repaint();
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {}
    @Override
    public void mouseClicked(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}

    // Undoable Action Interface
    private interface UndoableAction {
        void undo();
    }

    // Action for Shapes
    private class ShapeAction implements UndoableAction {
        private final Shape shape;
        private final Color color;

        public ShapeAction(Shape shape, Color color) {
            this.shape = shape;
            this.color = color;
        }

        @Override
        public void undo() {
            shapes.remove(shape);
            shapeColors.remove(color);
            shapeStrokes.remove(isDashed ? dashedStroke : solidStroke);
            shapeFilled.remove(shapeFilled.size() - 1); // Remove filled status
        }
    }

    // Action for Freehand Lines
    private class FreehandAction implements UndoableAction {
        private final List<Point> line;

        public FreehandAction(List<Point> line) {
            this.line = line;
        }

        @Override
        public void undo() {
            freehandLines.remove(line);
            freehandColors.remove(freehandColors.size() - 1);
            freehandStrokes.remove(freehandStrokes.size() - 1);
        }
    }

    // Action for Erasers
    private class EraserAction implements UndoableAction {
        private final Shape shape;

        public EraserAction(Shape shape) {
            this.shape = shape;
        }

        @Override
        public void undo() {
            shapes.remove(shape);
            shapeColors.add(currentColor);
            shapeStrokes.add(isDashed ? dashedStroke : solidStroke);
            shapeFilled.add(true); // Re-add filled status
        }
    }
}







